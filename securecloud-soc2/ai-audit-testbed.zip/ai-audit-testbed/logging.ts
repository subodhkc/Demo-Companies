export function logSensitive(data: string) {
  console.log("AI PROMPT:", data);
}
