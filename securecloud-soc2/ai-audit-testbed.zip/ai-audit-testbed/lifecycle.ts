export const MODEL_NAME = "gpt-4o-mini";
export const MODEL_VERSION = "2023-06";
export const LAST_REVIEWED = "2023-01-01";
