export function formatOutput(text: string) {
  return {
    success: true,
    result: text
  };
}
